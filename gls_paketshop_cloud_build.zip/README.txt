MEIN GLS PAKETSHOP – PROJEKTDATEIEN

ENTHALTEN
- web/: installierbare Web-App für Android (als eigenständige PWA über einen HTTPS-Webhost) und Windows 11 (Edge-App).
- android/: Android-Studio-Projekt zum Erzeugen einer APK.

WICHTIGE HINWEISE
1. Eine fertige APK ist in diesem Paket NICHT enthalten. Zum Bauen wird Android Studio mit Android SDK benötigt.
2. Die App speichert Einträge lokal auf dem jeweiligen Gerät. Für gemeinsamen Live-Datenstand zwischen Handy und Laptop wäre ein zusätzlicher Cloud-Dienst mit Benutzerkonto und Datenschutz-/Zugriffskonfiguration nötig. Bis dahin bitte Backup exportieren und auf dem anderen Gerät einspielen.
3. Die PWA muss einmal über eine HTTPS-Adresse bereitgestellt werden, damit Installation und Offline-Cache funktionieren. Die Android-Studio-App kann lokal als APK gebaut werden.
4. Die Provisionssätze sind nach der vom Nutzer bereitgestellten Kleinunternehmer-Provisionsliste voreingestellt. Vor Abrechnung bitte mit GLS-Abrechnung abgleichen.

APK BAUEN
- Android Studio installieren und den Ordner android öffnen.
- Gradle-Synchronisierung abwarten.
- Build > Build Bundle(s) / APK(s) > Build APK(s).
- Die APK liegt anschließend unter app/build/outputs/apk/debug/.

WINDOWS 11
- web/index.html über eine HTTPS-Veröffentlichung öffnen.
- In Microsoft Edge: Menü > Apps > Diese Website als App installieren.
- Für Offlinebetrieb muss die Seite vorher einmal online geladen worden sein.

DATENÜBERTRAGUNG
- In der App „Backup herunterladen“ wählen.
- Auf dem anderen Gerät die Datei öffnen und „Backup einspielen“ wählen.
